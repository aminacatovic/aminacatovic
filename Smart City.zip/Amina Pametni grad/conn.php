<?php

// konekcija sa bazom
$db = mysqli_connect('localhost', 'root', '', 'aminasajt');

session_start();
?>