<!DOCTYPE html>
<html>
<style>
.header {
 width: 30%;
  margin: 50px auto 0px;
  color: white;
  background: green;
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 10px 10px 0px 0px;
  padding: 20px;
}
a, h3 {
	color: white;
}
</style>
<body>
  <div class="header">
  	<h2> Molimo vas da se ulogujete kao profesor. Hvala.</h2>
	<h3><a href="login.php">Log in</a></h3>
<a href="index.php">Početna</a>
  </div>
</html>